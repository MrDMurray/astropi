#Team AGUA

from pathlib import Path
from logzero import logger, logfile
from sense_hat import SenseHat
from picamera import PiCamera
from orbit import ISS
from time import sleep
from datetime import datetime, timedelta
import csv

"""
Our messages from space:

From Sarah - I would like to thank  my mam and dad for helping me with my maths homework when i was younger. I would also like to thank my nanny for calling the ambulance when i caught my finger in the door when i was six years old.<3    
         ^..^      /
             /_/\_____/
               /\   /\
              /  \ /  \
From Rebecca - i would like to thank my dog for supporting me through this adventure xxxx thx dog. i would also like to thank my legs for always supporting me and my spine for always having my back

                ,-.___,-.
                \_/_ _\_/
                  )O_O(
                 { (_) }
                  `-^-'  

From Tracy - Hello mum👋 love you lots, thanks for all you do for me ;), hello to my big brother, hope college is treating you well.❤

             (    )  / ___ \ ) )  ( ( (    )   
             / /\ \ / /   \_| (    ) )/ /\ \   
            ( (__) | (  ____ ) )  ( (( (__) )  
            )    (( ( (__  | (    ) ))    (   
            /  /\  \\ \__/ / ) \__/ (/  /\  \  
           /__(  )__\\____/  \______/__(  )__\ 

From Georgia - Thank you to my mam whos got me so far, i love you, and thank you to my dad whos always been there. Yous are the best parents I could ask for. They have done their best to make me how I am today.  
 
              __ \/ __
             /o \{}/ o\
             \   ()   /
              `> /\ <`
              (o/\/\o)
               )    (  

"""

def make_the_csv_file(data_stored_directory):
    """Create a new CSV file and add the header row"""
    with open(data_stored_directory, 'w') as f:
        writer = csv.writer(f)
        header = ("Counter", "Date/time", "Latitude", "Longitude", "Temperature", "Humidity")
        writer.writerow(header)

def plus_data_from_csv(data_stored_directory, data):
    """Add a row of data to the data_stored_directory CSV"""
    with open(data_stored_directory, 'a') as f:
        writer = csv.writer(f)
        writer.writerow(data)

def calculate_angle(angle):
    """
    Work out a `skyfield` Angle and make it EXIF-appropriate
    """
    sign, degrees, minutes, seconds = angle.signed_dms()
    exif_angle = f'{degrees:.0f}/1,{minutes:.0f}/1,{seconds*10:.0f}/10'
    return sign < 0, exif_angle

def capture(camera, image):
    """Use `camera` to capture an `image` file with lat/long EXIF data."""
    location = ISS.coordinates()

    # calculate_angle the latitude and longitude to EXIF-appropriate representations
    south, exif_latitude = calculate_angle(location.latitude)
    west, exif_longitude = calculate_angle(location.longitude)

    # Set the EXIF tags specifying the current location
    camera.exif_tags['GPS.GPSLatitude'] = exif_latitude
    camera.exif_tags['GPS.GPSLatitudeRef'] = "S" if south else "N"
    camera.exif_tags['GPS.GPSLongitude'] = exif_longitude
    camera.exif_tags['GPS.GPSLongitudeRef'] = "W" if west else "E"

    # capture the image
    camera.capture(image)


base_folder = Path(__file__).parent.resolve()

# Set a logfile name
logfile(base_folder/"events.log")

# Set up Sense Hat
sense = SenseHat()

# Set up camera
cam = PiCamera()
cam.resolution = (4056, 3040) # Full throttle! (Don't worry, testing came out <3GB)

# Initialise the CSV file
data_stored_directory = base_folder/"data.csv"
make_the_csv_file(data_stored_directory)

# Initialise the photo counter
counter = 1
# Record the start and current time
begin_experiment = datetime.now()
current_time = datetime.now()
# Run a loop for (almost) three hours
while (current_time < begin_experiment + timedelta(minutes=161)): # 161 as 178 sometimes went over in testing
    try:
        humidity = round(sense.humidity, 4)
        temperature = round(sense.temperature, 4)
        # Get coordinates of location on Earth below the ISS
        location = ISS.coordinates()
        # Save the data to the file
        data = (
            counter,
            datetime.now(),
            location.latitude.degrees,
            location.longitude.degrees,
            temperature,
            humidity,
        )
        plus_data_from_csv(data_stored_directory, data)
        # capture image
        image_file = f"{base_folder}/photo_{counter:03d}.jpg"
        capture(cam, image_file)
        # Log event
        logger.info(f" is on iteration {counter} of about 470 or so. All good.")
        counter += 1
        sleep(20) # 20 as opposed to 30 or 60. This number came from hours of testing in bright light.
        # Update the current time
        current_time = datetime.now()
    except Exception as e:
        logger.error(f'{e.__class__.__name__}: {e}')

