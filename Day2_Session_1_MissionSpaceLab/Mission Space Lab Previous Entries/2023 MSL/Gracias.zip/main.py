
""" We are looking to see if there's a visible change (yellowing) to grassland colours.

                                   .__               
   ________________    ______ ____ |__|____    ______
  / ___\_  __ \__  \  /  ___// ___\|  \__  \  /  ___/
 / /_/  >  | \// __ \_\___ \\  \___|  |/ __ \_\___ \ 
 \___  /|__|  (____  /____  >\___  >__(____  /____  >
/_____/            \/     \/     \/        \/     \/ 

We are Ernests, Kyle, Ciaran, Liam, Kristians, and Lillie


# Final Test: 2.6GB Bright Photos. Less than 3GB, 2 hours 40 mins to complte so < 3 hour limit.


"""

from pathlib import Path
from logzero import logger, logfile
from sense_hat import SenseHat
from picamera import PiCamera
from orbit import ISS
from time import sleep
from datetime import datetime, timedelta
import csv

"""our programe is going to take """
def make_big_csv(info_file):
    """make a spread sheet for the data in the future"""
    with open(info_file, 'w') as f:
        writer = csv.writer(f)
        header = ("number_count", "Date/time", "Latitude", "Longitude", "Temperature", "Humidity")
        writer.writerow(header)

def data_goes_into_csv(info_file, data):
    """insert the data into the info_file CSV"""
    with open(info_file, 'a') as f:
        writer = csv.writer(f)
        writer.writerow(data)

def convert(angle):
    """convert the angle"""
    sign, degrees, minutes, seconds = angle.signed_dms()
    exif_angle = f'{degrees:.0f}/1,{minutes:.0f}/1,{seconds*10:.0f}/10'
    return sign < 0, exif_angle

def capture(camera, image):
    """Use `camera` to capture with lat/long EXIF data."""
    location = ISS.coordinates()

    south, exif_latitude = convert(location.latitude)
    west, exif_longitude = convert(location.longitude)
    
    camera.exif_tags['GPS.GPSLatitude'] = exif_latitude
    camera.exif_tags['GPS.GPSLatitudeRef'] = "S" if south else "N"
    camera.exif_tags['GPS.GPSLongitude'] = exif_longitude
    camera.exif_tags['GPS.GPSLongitudeRef'] = "W" if west else "E"

   
    camera.capture(image)
   

base_folder = Path(__file__).parent.resolve()


logfile(base_folder/"events.log")


sense = SenseHat()


cam = PiCamera()
cam.resolution = (4056, 3040) # first test was 1296, 972


info_file = base_folder/"data.csv"
make_big_csv(info_file)


number_count = 1

start_time = datetime.now()
now_time = datetime.now()

while (now_time < start_time + timedelta(minutes=160)): # default 178min
    try:
        humidity = round(sense.humidity, 4)
        temperature = round(sense.temperature, 4)
        
        location = ISS.coordinates()
        
        data = (
            number_count,
            datetime.now(),
            location.latitude.degrees,
            location.longitude.degrees,
            temperature,
            humidity,
        )
        data_goes_into_csv(info_file, data)
       
        image_file = f"{base_folder}/photo_{number_count:03d}.jpg"
        capture(cam, image_file)
      
        logger.info(f"My iteration count is {number_count} out of about 466")
        number_count += 1
        sleep(20) #default 30 seconds
        
        now_time = datetime.now()
    except Exception as e:
        logger.error(f'{e.__class__.__name__}: {e}')

#Personal messages:       
        
#lillie - I hope my dogs see this, they are pretty cool but they will probably just bark at the stars 

#Ernest: I hope my dad will be proud 

#Kristians:  My dad is my biggest supporter. I will make him proud.